import JsonEditor from "@/components/json-editor";
export default function Home() {
    return (
      <main>
        <JsonEditor/>
      </main>
    );
  }